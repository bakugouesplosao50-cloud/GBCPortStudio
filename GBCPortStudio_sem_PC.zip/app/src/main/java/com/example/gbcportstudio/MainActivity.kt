package com.example.gbcportstudio

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF101713)
private val Panel = Color(0xFF1B2921)
private val Green = Color(0xFFB5E853)
private val Muted = Color(0xFFA6B4A9)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GbcApp() }
    }
}

@Composable
fun GbcApp() {
    var selectedName by remember { mutableStateOf<String?>(null) }
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var showGame by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Nenhum jogo importado") }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            val name = uri.lastPathSegment?.substringAfterLast('/') ?: "ROM selecionada"
            selectedUri = uri
            selectedName = name
            status = "Arquivo selecionado. O núcleo GBC será integrado na próxima etapa."
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Green, background = Bg, surface = Panel,
        onPrimary = Color(0xFF17200F), onBackground = Color.White,
        onSurface = Color.White
    )) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            if (showGame) {
                GameScreen(
                    gameName = selectedName ?: "Jogo GBC",
                    onBack = { showGame = false }
                )
            } else {
                Column(
                    Modifier.fillMaxSize().padding(22.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Gamepad, null, tint = Green, modifier = Modifier.size(32.dp))
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("GBC PORT STUDIO", color = Green, fontSize = 20.sp, fontWeight = FontWeight.Black)
                            Text("Projeto Android • versão 0.1", color = Muted, fontSize = 12.sp)
                        }
                    }

                    Column(
                        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(20.dp)).padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("SUA BIBLIOTECA", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text(selectedName ?: "Sua biblioteca está vazia", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        Text(status, color = Muted, fontSize = 12.sp)
                        Button(
                            onClick = { picker.launch(arrayOf("*/*")) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color(0xFF17200F))
                        ) {
                            Icon(Icons.Default.FolderOpen, null)
                            Spacer(Modifier.width(8.dp))
                            Text("IMPORTAR ARQUIVO .GB / .GBC")
                        }
                        if (selectedName != null) {
                            OutlinedButton(
                                onClick = { showGame = true },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("ABRIR TELA DO JOGO") }
                        }
                    }

                    Column(
                        Modifier.fillMaxWidth().weight(1f).background(Color(0xFF152019), RoundedCornerShape(20.dp)).padding(18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        PixelScreen()
                        Spacer(Modifier.height(18.dp))
                        Text("PORT NATIVO PARA ANDROID", color = Green, fontWeight = FontWeight.Bold)
                        Text(
                            "Esta é a interface inicial. O motor que executa o jogo GBC ainda precisa ser integrado ou substituído pelo código-fonte do jogo escolhido.",
                            color = Muted, fontSize = 13.sp, lineHeight = 19.sp
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Save, null, tint = Green)
                        Spacer(Modifier.width(8.dp))
                        Text("Salvamento e execução serão conectados ao motor do jogo.", color = Muted, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun PixelScreen() {
    Box(
        Modifier.fillMaxWidth().aspectRatio(1.35f)
            .background(Color(0xFF9BBC0F), RoundedCornerShape(10.dp))
            .border(5.dp, Color(0xFF34452B), RoundedCornerShape(10.dp)),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("GBC", color = Color(0xFF34452B), fontSize = 38.sp, fontWeight = FontWeight.Black)
            Text("PORT STUDIO", color = Color(0xFF34452B), fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun GameScreen(gameName: String, onBack: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Bg).padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("‹  VOLTAR", color = Green, modifier = Modifier.clickable { onBack() })
            Spacer(Modifier.weight(1f))
            Text(gameName.take(24), color = Color.White, fontWeight = FontWeight.Bold)
        }
        Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                PixelScreen()
                Spacer(Modifier.height(12.dp))
                Text("MOTOR GBC AINDA NÃO INTEGRADO", color = Green, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("A tela e os controles estão preparados como protótipo.", color = Muted, fontSize = 11.sp)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            DPad()
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    RoundKey("B")
                    RoundKey("A")
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    SmallKey("SELECT")
                    SmallKey("START")
                }
            }
        }
    }
}

@Composable
private fun DPad() {
    Box(Modifier.size(142.dp), contentAlignment = Alignment.Center) {
        Box(Modifier.size(width = 46.dp, height = 138.dp).background(Color(0xFF34443A), RoundedCornerShape(8.dp)))
        Box(Modifier.size(width = 138.dp, height = 46.dp).background(Color(0xFF34443A), RoundedCornerShape(8.dp)))
        Text("＋", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun RoundKey(label: String) {
    Box(
        Modifier.size(58.dp).background(Color(0xFF8B3D5A), RoundedCornerShape(50)),
        contentAlignment = Alignment.Center
    ) { Text(label, color = Color.White, fontWeight = FontWeight.Black, fontSize = 20.sp) }
}

@Composable
private fun SmallKey(label: String) {
    Box(
        Modifier.width(70.dp).height(24.dp).background(Color(0xFF53635A), RoundedCornerShape(20.dp)),
        contentAlignment = Alignment.Center
    ) { Text(label, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold) }
}
