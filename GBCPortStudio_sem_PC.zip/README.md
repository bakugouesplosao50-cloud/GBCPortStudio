# GBC Port Studio — protótipo Android

Este projeto contém a primeira versão da interface de um aplicativo Android para um futuro port nativo de um jogo de Game Boy Color.

## O que já está implementado
- Tela inicial e biblioteca vazia.
- Seletor de arquivos para escolher um arquivo `.gb` ou `.gbc`.
- Tela de jogo de demonstração.
- Layout de controles touchscreen (direcional, A, B, Start e Select).

## O que ainda NÃO está implementado
- Não executa ROMs.
- Não contém um emulador.
- Não contém código de um jogo específico.
- Não é ainda um port nativo.

Para fazer um port nativo real, precisamos escolher um jogo cujo código-fonte esteja disponível e adaptar esse código para Android. A ROM importada nesta versão é apenas selecionada; não é executada.

## Como abrir
1. Extraia o ZIP.
2. Abra a pasta `GBCPortStudio` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Conecte um dispositivo Android ou use um emulador.
5. Use **Build > Build APK(s)**.

Requisitos: Android Studio recente, JDK 17 e conexão à internet na primeira sincronização do Gradle.

## Compilar sem PC (GitHub Actions)
1. Envie o conteúdo desta pasta para um repositório GitHub.
2. Abra a aba **Actions** do repositório.
3. Se necessário, autorize a execução de GitHub Actions.
4. Execute **Build Android APK** com **Run workflow** (ou aguarde o build automático após enviar para `main`).
5. Quando terminar, abra a execução e baixe o artefato **GBCPortStudio-debug**.
6. Extraia o ZIP baixado e instale `app-debug.apk` no Android.

A compilação na nuvem exige uma conta GitHub. O APK gerado é um protótipo de interface; ainda não executa ROMs nem contém um port de jogo.
